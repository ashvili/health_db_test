var _jq = (jQuery || django.jQuery);

_jq(document).ready(function(){
    // easy_select2() can take select2 constructor arguments object
    _jq('body').easy_select();
});
