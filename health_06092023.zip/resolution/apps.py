from django.apps import AppConfig


class ResolutionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'resolution'
    verbose_name = 'Решения'
