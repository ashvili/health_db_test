from django.contrib import admin

from .models import PatientResolution


admin.site.register(PatientResolution)
