from django.contrib import admin

from .models import PatientTherapy


admin.site.register(PatientTherapy)

