from django.apps import AppConfig


class SurgeryConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'surgery'
    verbose_name = 'Операции'
