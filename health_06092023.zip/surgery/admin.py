from django.contrib import admin

from .models import PatientSurgery


admin.site.register(PatientSurgery)