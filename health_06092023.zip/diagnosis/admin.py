from django.contrib import admin

from .models import PatientDiagnosis


admin.site.register(PatientDiagnosis)